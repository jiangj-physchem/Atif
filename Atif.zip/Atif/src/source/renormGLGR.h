//*************declaration the functions for RenormGLGR***********//
//****************************************************************//
#ifndef RENORMGLGR_H_
#define RENORMGLGR_H_
#include "clibrary.h"
using namespace std;
void RenormGLGR(float* D,double* rhoB,double*** BesselZero,string* MODEL);
#endif//RENORMGLGR_H_

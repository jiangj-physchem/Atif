//****declaration the functions for get numbers line by line******//
//****************************************************************//
#ifndef GETNUMBERSBYLINE_H_
#define GETNUMBERSBYLINE_H_
#include "clibrary.h"
using namespace std;
void GetNumbersByLine(ifstream& inFile,double* getNum);
#endif//GETNUMBERSBYLINE_H_

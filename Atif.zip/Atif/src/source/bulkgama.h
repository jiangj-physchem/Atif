//*(declaration the function for calculating bulk gama*//
//***********************Gama*************************//
#ifndef BULKGAMA_H_
#define BULKGAMA_H_
void BulkGama(double* rhoB,float* D,float* Z,double& gama);
#endif //BULKGAMA_H_

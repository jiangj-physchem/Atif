//****calculating local screening parameter Gama(r) in funtionalized MSA***//
#ifndef LOCALGAMA_H_
#define LOCALGAMA_H_
void LocalGama(double gammab,int* LLI,int* ULI,float* D,float* Z,double** rho,double* gamar);
#endif //LOCALGAMA_H_

//********declaration the function for calculating gama******//
//***********************************************************//
#ifndef CALCULATEGAMA_H_
#define CALCULATEGAMA_H_
double CalculateGama(float* Z,float* D,double** QI_k);
double CalculateGama(float* Z,float* D,double** H,double* QI_k);
#endif //CALCULATEGAMA_H_

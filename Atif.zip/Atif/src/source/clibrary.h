//define clibrary.h
#ifndef CLIBRARY_H_
#define CLIBRARY_H_
#include <cstdlib>   // rand(),srand()
#include <iostream>
#include <fstream>
#include <cmath>
#include <ctime>     //time()
#include <string>
#include <cstring>
#include <sstream>
#endif // CLIBRARY_H_
